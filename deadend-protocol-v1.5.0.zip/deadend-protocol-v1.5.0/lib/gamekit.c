/* ==========================================================================
 * DeadEnd 2D Game Kit -- gamekit.c  (built on raylib 5.5)
 * ========================================================================== */
#include "gamekit.h"
#include "motionkit.h"
#include "raylib.h"
#include <stdlib.h>
#include <math.h>

DEPGameConfig dep_game_config = { NULL, 800, 600, 60, 0, NULL, NULL };

int dep_window_open = 0;
static int  dep_audio_ready = 0;
static char dep_prev_keys[512] = { 0 };

/* ---------------- colors ---------------- */
typedef struct { const char *name; unsigned int rgb; } DEPColorName;
static const DEPColorName DEP_COLORS[] = {
    {"black", 0x000000}, {"white", 0xFFFFFF}, {"gray", 0x808080},
    {"grey", 0x808080}, {"light gray", 0xD3D3D3}, {"light grey", 0xD3D3D3},
    {"dark gray", 0x404040}, {"dark grey", 0x404040},
    {"red", 0xE63946}, {"dark red", 0x8B0000}, {"light red", 0xFF6B6B},
    {"orange", 0xF77F00}, {"gold", 0xE9C46A}, {"yellow", 0xFFD166},
    {"green", 0x2A9D8F}, {"dark green", 0x1B4332}, {"light green", 0x8AC926},
    {"lime", 0xB5E48C}, {"mint", 0x99D98C}, {"teal", 0x168AAD},
    {"cyan", 0x00BCD4}, {"blue", 0x1D4E89}, {"dark blue", 0x0D1B2A},
    {"night blue", 0x14213D}, {"light blue", 0x89C2D9}, {"sky blue", 0x87CEEB},
    {"navy", 0x03045E}, {"purple", 0x6D597A}, {"violet", 0x9D4EDD},
    {"pink", 0xFF8FA3}, {"magenta", 0xD81159}, {"brown", 0x8D6E63},
    {"tan", 0xE3D5CA}, {"cream", 0xFFF8E7}, {"beige", 0xF5EBDC},
    {"peach", 0xFFDAB9}, {"coral", 0xFF7F50}, {"salmon", 0xFA8072},
    {"indigo", 0x3A0CA3}, {"maroon", 0x800000}, {"olive", 0x6B8E23},
    {"slate", 0x708090}, {"silver", 0xC0C0C0}, {NULL, 0}
};

static Color dep_color_of(DEPValue v) {
    Color c = BLACK;
    if (v.tag == DEP_T_TEXT) {
        const char *s = v.as.s->chars;
        long len = v.as.s->len;
        if (len > 0 && s[0] == '#' && (len == 7 || len == 9)) {
            unsigned int r = 0, g = 0, b = 0, a = 255;
            char buf[3] = { 0, 0, 0 };
            buf[0] = s[1]; buf[1] = s[2]; r = (unsigned int)strtoul(buf, NULL, 16);
            buf[0] = s[3]; buf[1] = s[4]; g = (unsigned int)strtoul(buf, NULL, 16);
            buf[0] = s[5]; buf[1] = s[6]; b = (unsigned int)strtoul(buf, NULL, 16);
            if (len == 9) { buf[0] = s[7]; buf[1] = s[8]; a = (unsigned int)strtoul(buf, NULL, 16); }
            c.r = (unsigned char)r; c.g = (unsigned char)g; c.b = (unsigned char)b; c.a = (unsigned char)a;
        } else {
            for (int i = 0; DEP_COLORS[i].name; i++) {
                if (strcmp(s, DEP_COLORS[i].name) == 0) {
                    unsigned int rgb = DEP_COLORS[i].rgb;
                    c.r = (unsigned char)(rgb >> 16);
                    c.g = (unsigned char)((rgb >> 8) & 0xFF);
                    c.b = (unsigned char)(rgb & 0xFF);
                    c.a = 255;
                    break;
                }
            }
        }
    } else if (v.tag == DEP_T_NUM) {
        /* packed 0xRRGGBB number */
        unsigned int rgb = (unsigned int)v.as.n;
        c.r = (unsigned char)(rgb >> 16);
        c.g = (unsigned char)((rgb >> 8) & 0xFF);
        c.b = (unsigned char)(rgb & 0xFF);
        c.a = 255;
    }
    dep_release(v);
    return c;
}

static const char *dep_cstr(DEPValue v, const char *what) {
    if (v.tag != DEP_T_TEXT) {
        dep_die("%s needs text, got %s", what, dep_typename(v));
    }
    const char *s = v.as.s->chars;   /* borrowed: caller must keep v alive */
    return s;
}

/* ---------------- keys ---------------- */
typedef struct { const char *name; int key; } DEPKeyName;
static const DEPKeyName DEP_KEYS[] = {
    {"up", KEY_UP}, {"down", KEY_DOWN}, {"left", KEY_LEFT}, {"right", KEY_RIGHT},
    {"space", KEY_SPACE}, {"enter", KEY_ENTER}, {"return", KEY_ENTER},
    {"escape", KEY_ESCAPE}, {"esc", KEY_ESCAPE},
    {"backspace", KEY_BACKSPACE}, {"tab", KEY_TAB},
    {"shift", KEY_LEFT_SHIFT}, {"left shift", KEY_LEFT_SHIFT},
    {"right shift", KEY_RIGHT_SHIFT},
    {"ctrl", KEY_LEFT_CONTROL}, {"control", KEY_LEFT_CONTROL},
    {"alt", KEY_LEFT_ALT},
    {"delete", KEY_DELETE}, {"insert", KEY_INSERT},
    {"home", KEY_HOME}, {"end", KEY_END},
    {"page up", KEY_PAGE_UP}, {"page down", KEY_PAGE_DOWN},
    {"caps lock", KEY_CAPS_LOCK},
    {"left", KEY_LEFT}, {"right", KEY_RIGHT},
    {NULL, 0}
};

static int dep_key_of(const char *s) {
    if (!s[0]) return -1;
    if (!s[1]) {   /* single character: letter, digit, punctuation */
        char c = s[0];
        if (c >= 'a' && c <= 'z') return KEY_A + (c - 'a');
        if (c >= 'A' && c <= 'Z') return KEY_A + (c - 'A');
        if (c >= '0' && c <= '9') return KEY_ZERO + (c - '0');
    }
    for (int i = 0; DEP_KEYS[i].name; i++)
        if (strcmp(s, DEP_KEYS[i].name) == 0) return DEP_KEYS[i].key;
    if (s[0] == 'f' && s[1] >= '1' && s[1] <= '9' && !s[2]) {
        int n = s[1] - '0';
        if (n >= 1 && n <= 8) return KEY_F1 + (n - 1);
        if (n == 9) return KEY_F9;
    }
    if (s[0] == 'f' && s[1] == '1' && s[2] >= '0' && s[2] <= '2' && !s[3])
        return KEY_F10 + (s[2] - '0');
    return -1;
}

int dep_g_holding(DEPValue key) {
    const char *s = dep_cstr(key, "holding");
    int k = dep_key_of(s);
    if (k < 0) { dep_die("I don't know the key '%s'", s); }
    dep_release(key);
    return IsKeyDown((KeyboardKey)k);
}

int dep_g_pressed(DEPValue key) {
    const char *s = dep_cstr(key, "pressed");
    int k = dep_key_of(s);
    if (k < 0) { dep_die("I don't know the key '%s'", s); }
    int now = IsKeyDown((KeyboardKey)k);
    int was = dep_prev_keys[k & 511];
    int r = now && !was;
    dep_release(key);
    return r;
}

/* ---------------- mouse ---------------- */
static DEPMap *dep_mouse_map = NULL;

DEPMap *dep_g_mouse(void) {
    if (!dep_mouse_map) {
        dep_mouse_map = dep_map_new();
        dep_map_set_field(dep_mouse_map, "x", dep_n(0));
        dep_map_set_field(dep_mouse_map, "y", dep_n(0));
        dep_map_set_field(dep_mouse_map, "left", dep_b(0));
        dep_map_set_field(dep_mouse_map, "right", dep_b(0));
        dep_map_set_field(dep_mouse_map, "click", dep_b(0));
        dep_map_set_field(dep_mouse_map, "rclick", dep_b(0));
        dep_mouse_map->refs++;   /* permanent */
    }
    return dep_mouse_map;
}

static void dep_mouse_update(void) {
    DEPMap *m = dep_g_mouse();
    dep_map_set_field(m, "x", dep_n(GetMouseX()));
    dep_map_set_field(m, "y", dep_n(GetMouseY()));
    dep_map_set_field(m, "left", dep_b(IsMouseButtonDown(MOUSE_BUTTON_LEFT)));
    dep_map_set_field(m, "right", dep_b(IsMouseButtonDown(MOUSE_BUTTON_RIGHT)));
    dep_map_set_field(m, "click", dep_b(IsMouseButtonPressed(MOUSE_BUTTON_LEFT)));
    dep_map_set_field(m, "rclick", dep_b(IsMouseButtonPressed(MOUSE_BUTTON_RIGHT)));
}

/* ---------------- setup + run ---------------- */
void dep_game_setup(DEPValue title, double w, double h, double fps, int fullscreen) {
    if (dep_game_config.title) free(dep_game_config.title);
    const char *s = (title.tag == DEP_T_TEXT) ? title.as.s->chars : "DeadEnd Game";
    dep_game_config.title = (char *)malloc(strlen(s) + 1);
    if (dep_game_config.title) strcpy(dep_game_config.title, s);
    else dep_die("out of memory");
    if (w > 0) dep_game_config.width = w;
    if (h > 0) dep_game_config.height = h;
    if (fps > 0) dep_game_config.fps = fps;
    dep_game_config.fullscreen = fullscreen;
    dep_release(title);
}

static void dep_g_open_window(void) {
    if (!dep_window_open) {
        if (getenv("DEP_TRACE")) SetTraceLogLevel(LOG_INFO);
        else SetTraceLogLevel(LOG_WARNING);   /* DEP_TRACE=1 shows raylib init details */
        if (!dep_game_config.title) {
            dep_game_config.title = (char *)malloc(16);
            strcpy(dep_game_config.title, "DeadEnd Game");
        }
        InitWindow((int)dep_game_config.width, (int)dep_game_config.height,
                   dep_game_config.title);
        /* Bug fix (41): raylib keeps running with no window when the
           graphics device fails, the game loop then exits at once and the
           whole program ends silently with code 0. Fail loudly instead. */
        if (!IsWindowReady()) {
            dep_die("I could not open the game window (%d x %d) -- your "
                    "graphics driver refused an OpenGL 3.3 context. Update "
                    "your display driver and try again; run the program with "
                    "DEP_TRACE=1 to see the graphics system's own error "
                    "lines.",
                    (int)dep_game_config.width, (int)dep_game_config.height);
        }
        if (dep_game_config.fullscreen) ToggleFullscreen();
        SetTargetFPS((int)dep_game_config.fps);
        dep_window_open = 1;
    }
}

void dep_game_run(void) {
    dep_g_open_window();
    if (dep_game_config.on_start) dep_game_config.on_start();
    long limit = -1;
    const char *fl = getenv("DEP_FRAMES");
    if (fl) limit = atol(fl);
    long n = 0;
    while (!WindowShouldClose()) {
        dep_mouse_update();
        /* motion kit: step every animation, then let it move variables */
        dep_m_set_screen(GetScreenWidth(), GetScreenHeight());
        dep_motion_tick(GetFrameTime());
        BeginDrawing();
        ClearBackground(BLACK);
        double cam_ox, cam_oy, cam_zoom;
        int have_cam = dep_m_camera(&cam_ox, &cam_oy, &cam_zoom);
        if (have_cam) {
            Camera2D cam;
            cam.offset.x = (float)(GetScreenWidth() / 2.0 + cam_ox);
            cam.offset.y = (float)(GetScreenHeight() / 2.0 + cam_oy);
            cam.target.x = (float)(GetScreenWidth() / 2.0);
            cam.target.y = (float)(GetScreenHeight() / 2.0);
            cam.zoom = (float)cam_zoom;
            cam.rotation = 0.0f;
            BeginMode2D(cam);
        }
        if (dep_game_config.on_frame) dep_game_config.on_frame();
        dep_g_draw_particles();
        if (have_cam) EndMode2D();
        {
            double r, g, b, a;
            if (dep_m_overlay(&r, &g, &b, &a) && a > 0.002)
                DrawRectangle(0, 0, GetScreenWidth(), GetScreenHeight(),
                              (Color) { (unsigned char)(r * 255.0),
                                        (unsigned char)(g * 255.0),
                                        (unsigned char)(b * 255.0),
                                        (unsigned char)(a * 255.0) });
        }
        EndDrawing();
        /* snapshot key states for 'pressed' edge detection next frame */
        for (int k = 0; k < 512; k++) dep_prev_keys[k] = IsKeyDown((KeyboardKey)k) ? 1 : 0;
        if (limit > 0 && ++n >= limit) break;
    }
    CloseWindow();
    dep_window_open = 0;
}

/* ---------------- drawing ---------------- */
#define DEP_MAX_TEX 128
typedef struct { char *name; Texture2D tex; } DEPTexSlot;
static DEPTexSlot dep_textures[DEP_MAX_TEX];
static int dep_tex_count = 0;

static Texture2D dep_tex(const char *s) {
    for (int i = 0; i < dep_tex_count; i++)
        if (strcmp(dep_textures[i].name, s) == 0) return dep_textures[i].tex;
    Texture2D t = { 0 };
    if (dep_tex_count < DEP_MAX_TEX) {
        t = LoadTexture(s);
        dep_textures[dep_tex_count].name = (char *)malloc(strlen(s) + 1);
        strcpy(dep_textures[dep_tex_count].name, s);
        dep_textures[dep_tex_count].tex = t;
        dep_tex_count++;
    }
    return t;
}

static void dep_need_window(const char *what) {
    if (!dep_window_open)
        dep_die("%s can only be used while the game window is open "
                "(put it inside 'every frame')", what);
}

void dep_g_clear(DEPValue color) {
    dep_need_window("clear");
    ClearBackground(dep_color_of(color));
}
void dep_g_pixel(double x, double y, DEPValue color) {
    dep_need_window("pixel");
    DrawPixel((int)x, (int)y, dep_color_of(color));
}
void dep_g_line(double x1, double y1, double x2, double y2, DEPValue color) {
    dep_need_window("line");
    DrawLine((int)x1, (int)y1, (int)x2, (int)y2, dep_color_of(color));
}
void dep_g_box(double x, double y, double w, double h, DEPValue color) {
    dep_need_window("box");
    DrawRectangle((int)x, (int)y, (int)w, (int)h, dep_color_of(color));
}
void dep_g_circle(double x, double y, double r, DEPValue color) {
    dep_need_window("circle");
    DrawCircle((int)x, (int)y, (float)r, dep_color_of(color));
}
void dep_g_ring(double x, double y, double r, DEPValue color) {
    dep_need_window("ring");
    DrawCircleLines((int)x, (int)y, (float)r, dep_color_of(color));
}
void dep_g_write(DEPValue text, double x, double y, double size, DEPValue color) {
    dep_need_window("write");
    DEPValue tv = dep_text_of(text);   /* numbers become text too */
    Color c = dep_color_of(color);
    DrawText(tv.as.s->chars, (int)x, (int)y, (int)(size < 6 ? 6 : size), c);
    dep_release(tv);
    dep_release(text);
}
void dep_g_image3(DEPValue file, double x, double y) {
    dep_need_window("image");
    const char *s = dep_cstr(file, "image");
    Texture2D t = dep_tex(s);
    DrawTexture(t, (int)x, (int)y, WHITE);
    dep_release(file);
}
void dep_g_image5(DEPValue file, double x, double y, double w, double h) {
    dep_need_window("image");
    const char *s = dep_cstr(file, "image");
    Texture2D t = dep_tex(s);
    Rectangle src = { 0, 0, (float)t.width, (float)t.height };
    Rectangle dst = { (float)x, (float)y, (float)w, (float)h };
    Vector2 org = { 0, 0 };
    DrawTexturePro(t, src, dst, org, 0.0f, WHITE);
    dep_release(file);
}

/* shared renderer for the fancy image options: draws one source rectangle
   of a texture at a destination rectangle, optionally flipped.
   w or h below 0 means "use the source's own size". */
static void dep_image_draw(Texture2D t, double x, double y, double w, double h,
                           double sx, double sy, double sw, double sh,
                           int flip_v, int flip_h) {
    Rectangle src = { (float)sx, (float)sy, (float)sw, (float)sh };
    if (flip_v) { src.y += src.height; src.height = -src.height; }
    if (flip_h) { src.x += src.width; src.width = -src.width; }
    if (w < 0) w = sw;
    if (h < 0) h = sh;
    Rectangle dst = { (float)x, (float)y, (float)w, (float)h };
    Vector2 org = { 0, 0 };
    DrawTexturePro(t, src, dst, org, 0.0f, WHITE);
}

/* image "sheet.png", x, y, w, h, frame n of m [, flipped] [, mirrored] */
void dep_g_image_frame(DEPValue file, double x, double y, double w, double h,
                       double n, double m, double flip_v, double flip_h) {
    dep_need_window("image");
    const char *s = dep_cstr(file, "image");
    Texture2D t = dep_tex(s);
    int mm = (int)m, nn = (int)n;
    if (mm < 1)
        dep_die("image 'frame %d of %d': a picture needs at least 1 frame", nn, mm);
    if (nn < 1 || nn > mm)
        dep_die("image 'frame %d of %d': there is no frame %d (pictures count "
                "frames from 1)", nn, mm, nn);
    double sw = (double)t.width / mm;
    double sx = (nn - 1) * sw;
    dep_image_draw(t, x, y, w, h, sx, 0, sw, (double)t.height,
                   (int)flip_v, (int)flip_h);
    dep_release(file);
}

/* image "pic.png", x, y, w, h, part sx, sy, sw, sh [, flipped] [, mirrored] */
void dep_g_image_part(DEPValue file, double x, double y, double w, double h,
                      double sx, double sy, double sw, double sh,
                      double flip_v, double flip_h) {
    dep_need_window("image");
    const char *s = dep_cstr(file, "image");
    Texture2D t = dep_tex(s);
    if (sw <= 0 || sh <= 0)
        dep_die("image 'part %g, %g, %g, %g': part width and height must be "
                "bigger than 0", sx, sy, sw, sh);
    if (sx < 0 || sy < 0 || sx + sw > (double)t.width + 0.5 ||
        sy + sh > (double)t.height + 0.5)
        dep_die("image 'part %g, %g, %g, %g' goes outside %s "
                "(it is %d by %d pixels)",
                sx, sy, sw, sh, s, t.width, t.height);
    dep_image_draw(t, x, y, w, h, sx, sy, sw, sh, (int)flip_v, (int)flip_h);
    dep_release(file);
}

/* ---------------- audio ---------------- */
#define DEP_MAX_SOUNDS 64
typedef struct { char *name; Sound snd; } DEPSoundSlot;
static DEPSoundSlot dep_sounds[DEP_MAX_SOUNDS];
static int dep_sound_count = 0;
static Music dep_music = { 0 };
static char *dep_music_name = NULL;
static int dep_music_playing = 0;

static void dep_audio_init(void) {
    if (!dep_audio_ready) {
        InitAudioDevice();
        dep_audio_ready = 1;
    }
}

void dep_g_sound(DEPValue file) {
    if (file.tag != DEP_T_TEXT) { dep_release(file); return; }
    const char *s = file.as.s->chars;
    for (int i = 0; i < dep_sound_count; i++) {
        if (strcmp(dep_sounds[i].name, s) == 0) {
            PlaySound(dep_sounds[i].snd);
            dep_release(file);
            return;
        }
    }
    if (dep_sound_count < DEP_MAX_SOUNDS) {
        dep_audio_init();
        dep_sounds[dep_sound_count].name = (char *)malloc(strlen(s) + 1);
        strcpy(dep_sounds[dep_sound_count].name, s);
        dep_sounds[dep_sound_count].snd = LoadSound(s);
        PlaySound(dep_sounds[dep_sound_count].snd);
        dep_sound_count++;
    }
    dep_release(file);
}

void dep_g_music(DEPValue file) {
    if (file.tag != DEP_T_TEXT) { dep_release(file); return; }
    const char *s = file.as.s->chars;
    if (dep_music_name && strcmp(dep_music_name, s) == 0) { dep_release(file); return; }
    dep_audio_init();
    if (dep_music_playing) { StopMusicStream(dep_music); dep_music_playing = 0; }
    if (dep_music_name) { free(dep_music_name); dep_music_name = NULL; }
    /* release the previous track's stream (safe on a zeroed Music too:
       UnloadAudioBuffer(NULL) is a no-op), else every track switch leaks it */
    UnloadMusicStream(dep_music);
    dep_music = (Music){ 0 };
    if (s[0] == '\0') { dep_release(file); return; }   /* music "" stops music */
    dep_music = LoadMusicStream(s);
    dep_music_name = (char *)malloc(strlen(s) + 1);
    strcpy(dep_music_name, s);
    PlayMusicStream(dep_music);
    dep_music_playing = 1;
    dep_release(file);
}

void dep_g_silence(void) {
    if (dep_music_playing) { StopMusicStream(dep_music); dep_music_playing = 0; }
}

/* ---------------- timing + misc ---------------- */
double dep_g_time(void)  { return GetTime(); }
double dep_g_delta(void) { return GetFrameTime(); }

static double dep_field_num(DEPValue m, const char *k) {
    DEPValue v = dep_field(m, k);      /* dep_field returns an owned value */
    double r = (v.tag == DEP_T_NUM) ? v.as.n : 0;
    dep_release(v);                    /* release it: else 'hits' leaks */
    return r;
}

int dep_g_hits(DEPValue a, DEPValue b) {
    if (a.tag != DEP_T_MAP || b.tag != DEP_T_MAP) {
        dep_die("hits needs two maps with x, y, w and h fields "
                "(got %s and %s)", dep_typename(a), dep_typename(b));
    }
    double ax = dep_field_num(a, "x"), ay = dep_field_num(a, "y");
    double aw = dep_field_num(a, "w"), ah = dep_field_num(a, "h");
    double bx = dep_field_num(b, "x"), by = dep_field_num(b, "y");
    double bw = dep_field_num(b, "w"), bh = dep_field_num(b, "h");
    dep_release(a); dep_release(b);
    return (ax < bx + bw && bx < ax + aw && ay < by + bh && by < ay + ah);
}

void dep_set_title(DEPValue title) {
    if (dep_window_open && title.tag == DEP_T_TEXT) {
        SetWindowTitle(title.as.s->chars);
        if (dep_game_config.title) free(dep_game_config.title);
        dep_game_config.title = (char *)malloc(title.as.s->len + 1);
        strcpy(dep_game_config.title, title.as.s->chars);
    }
    dep_release(title);
}

/* ==========================================================================
 * Motion kit render hooks + color-resolving wrappers (v1.4.0)
 * ========================================================================== */

void dep_g_draw_particles(void) {
    MParticleView p;
    long n = dep_m_particle_count();
    for (long i = 0; i < n; i++) {
        if (!dep_m_particle_at(i, &p)) break;
        float frac = (p.maxlife > 0) ? p.life / p.maxlife : 0.0f;
        Color c = { (unsigned char)(p.r * 255.0f), (unsigned char)(p.g * 255.0f),
                    (unsigned char)(p.b * 255.0f),
                    (unsigned char)(p.a * frac * 255.0f) };
        switch (p.kind) {
        case DEP_PK_CONFETTI: {
            Vector2 org = { p.size / 2.0f, p.size * 0.3f };
            DrawRectanglePro((Rectangle) { p.x, p.y, p.size, p.size * 0.62f },
                             org, p.rot, c);
            break;
        }
        case DEP_PK_SMOKE: {
            float grow = 1.0f + (1.0f - frac) * 1.6f;
            Color sc = c;
            sc.a = (unsigned char)(p.a * frac * frac * 255.0f);
            DrawCircle((int)p.x, (int)p.y, p.size * grow, sc);
            break;
        }
        case DEP_PK_STAR: {
            Vector2 a1 = { p.x - p.size, p.y }, a2 = { p.x + p.size, p.y };
            Vector2 b1 = { p.x, p.y - p.size }, b2 = { p.x, p.y + p.size };
            DrawLineEx(a1, a2, 1.6f, c);
            DrawLineEx(b1, b2, 1.6f, c);
            break;
        }
        case DEP_PK_FIRE: {
            /* yellow-white core cooling to deep red with age */
            float age = 1.0f - frac;
            Color fc = { (unsigned char)(255.0f),
                         (unsigned char)((0.82f - 0.62f * age) * 255.0f),
                         (unsigned char)((0.25f - 0.22f * age) * 255.0f),
                         (unsigned char)(frac * 230.0f) };
            DrawCircle((int)p.x, (int)p.y, p.size * (0.4f + 0.6f * frac), fc);
            break;
        }
        case DEP_PK_BUBBLE:
            DrawCircleLines((int)p.x, (int)p.y, p.size, c);
            break;
        case DEP_PK_HEART: {
            float s = p.size * 0.5f;
            DrawCircle((int)(p.x - s * 0.5f), (int)(p.y - s * 0.35f), s * 0.55f, c);
            DrawCircle((int)(p.x + s * 0.5f), (int)(p.y - s * 0.35f), s * 0.55f, c);
            Vector2 v1 = { p.x - s, p.y - s * 0.15f };
            Vector2 v2 = { p.x + s, p.y - s * 0.15f };
            Vector2 v3 = { p.x, p.y + s * 0.85f };
            DrawTriangle(v1, v2, v3, c);
            break;
        }
        case DEP_PK_RAIN: {
            Vector2 a1 = { p.x, p.y };
            Vector2 a2 = { p.x - p.vx * 0.02f, p.y + p.size };
            DrawLineEx(a1, a2, 1.4f, c);
            break;
        }
        default:  /* sparks, snow, custom */
            DrawCircle((int)p.x, (int)p.y, p.size * (p.kind == DEP_PK_SPARK ? frac : 1.0f), c);
            break;
        }
    }
}

/* ---- wrapper API the generated code calls (colors resolved here) ---- */

void dep_g_shake(double strength, double dur) {
    dep_m_shake(strength, dur);
}

void dep_g_flash(DEPValue color, double dur) {
    Color c = dep_color_of(color);
    dep_m_flash(c.r / 255.0, c.g / 255.0, c.b / 255.0, dur);
}

void dep_g_fade_to(DEPValue color, double dur) {
    Color c = dep_color_of(color);
    dep_m_fade_to(c.r / 255.0, c.g / 255.0, c.b / 255.0, dur);
}

void dep_g_fade_from(DEPValue color, double dur) {
    Color c = dep_color_of(color);
    dep_m_fade_from(c.r / 255.0, c.g / 255.0, c.b / 255.0, dur);
}

void dep_g_zoom(double target, double dur, DEPValue feel) {
    const char *f = (feel.tag == DEP_T_TEXT) ? feel.as.s->chars : NULL;
    dep_m_zoom(target, dur, f);
    dep_release(feel);
}

static float *dep_g_rgba_of(DEPValue color, float out[4]) {
    Color c = dep_color_of(color);
    out[0] = c.r / 255.0f; out[1] = c.g / 255.0f;
    out[2] = c.b / 255.0f; out[3] = c.a / 255.0f;
    return out;
}

void dep_g_burst(DEPValue kind, double n, double x, double y,
                 DEPValue color, double speed, double size, double life) {
    const char *k = dep_cstr(kind, "burst");
    int kid = dep_m_particle_kind(k);
    if (kid < 0)
        dep_die("I don't know the particle kind '%s' (try sparks, confetti, "
                "smoke, stars, fire, bubbles, hearts)", k);
    float rgba[4];
    float *col = NULL;
    if (color.tag == DEP_T_TEXT && color.as.s->len > 0)
        col = dep_g_rgba_of(color, rgba);
    else
        dep_release(color);
    dep_m_burst(kid, n, x, y, col, speed, size, life);
    dep_release(kind);                 /* borrowed by k until now */
}

void dep_g_rain(double n, DEPValue color, double speed, double size,
                double life) {
    float rgba[4];
    float *col = NULL;
    if (color.tag == DEP_T_TEXT && color.as.s->len > 0)
        col = dep_g_rgba_of(color, rgba);
    else
        dep_release(color);
    dep_m_rain(n, col, speed, size, life);
}

void dep_g_snow(double n, DEPValue color, double speed, double size,
                double life) {
    float rgba[4];
    float *col = NULL;
    if (color.tag == DEP_T_TEXT && color.as.s->len > 0)
        col = dep_g_rgba_of(color, rgba);
    else
        dep_release(color);
    dep_m_snow(n, col, speed, size, life);
}
