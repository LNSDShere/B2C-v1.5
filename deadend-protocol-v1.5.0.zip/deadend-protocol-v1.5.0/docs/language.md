# The DeadEnd language reference

Everything in DeadEnd is designed around one rule: **if it doesn't read like
a sentence, it doesn't go in the language.**

## Values

| What        | How to write it                      |
|-------------|--------------------------------------|
| number      | `3`  `3.14`  `1000000000`            |
| text        | `"anything in quotes"`               |
| yes / no    | `yes`  `no`                          |
| nothing     | `nothing`                            |
| list        | `[1, 2, 3]`  `[]`                    |
| map         | `{name: "Ada", x: 100}`              |

Text joins with `+` (numbers convert automatically): `"age: " + 30`.

## Names and assignment

```
set score to 0          # create or change a name
set hero.x to 150       # set a map field
set items[2] to 99      # set a list position (1-based)
change score by 10      # same as: set score to score + 10
```

Names declared at the top level are **global** — every function can see them.
Names first set inside a function are local to that function. You cannot read
a name before giving it a value; the compiler catches most typos this way.

## Printing and asking

```
print "x is", x                 # several values, space-separated
set name to ask "What is your name? "
```

## Decisions

```
if x is 5                       # equality (numbers, text, yes/no)
if x is not 5
if x is more than 5             # also: greater than / bigger than
if x is less than 5             # also: fewer than / smaller than
if x is at least 5
if x is at most 5
if x > 5                        # symbols work too: > < >= <=
if x is 5 then print "five"     # one-liner: no 'end' needed
```

Combine with `and`, `or`, `not`. Only `no`, `nothing`, `0` and `""` are false.

## Repetition

```
repeat 10 times                 # counted
  ...
end

repeat with i from 1 to 100     # counted range
  ...
end

repeat with i from 100 to 0 by -5   # backwards / stepping
  ...
end

repeat forever
  ...
end

while fuel is more than 0
  ...
end

for each item in items
  ...
end

break                           # leave the loop
continue                        # skip to the next round
```

## Lists

```
set items to [1, 2, 3]
add 4 to items                  # append
print items[1]                  # position 1 (the first one)
print items[-1]                 # the last one
set items[2] to 99
remove item 2 from items        # remove by position
remove "red" from items         # remove by value
print count of items            # length
print first of items
print last of items
if items has 3                  # membership
sort items
reverse items
shuffle items
```

## Maps

A map is a value with named fields.

```
set hero to {name: "Ada", x: 100, y: 50}
print hero.name                 # dot reads a field
set hero.x to 150
change hero.health by -3
print count of hero             # how many fields
if hero has "name"              # does the field exist
for each key in keys of hero    # walk the field names
  print key, "is", hero's...    # (use hero[key-style access below])
end
print hero["name"]              # bracket access works too
remove "x" from hero            # delete a field
```

## Text tools

```
count of "hello"                # 5
"hello"[1]                      # "h"
upper "quiet"                   # "QUIET"
lower "LOUD"                    # "loud"
trim "  pad  "                  # "pad"
split "a,b,c", ","              # ["a", "b", "c"]
join items, ", "                # one text from a list
find "hello", "llo"             # position, or 0 if absent
replace("cats and dogs", "and", "or")
find items, 3                   # position of a value in a list
text 42                         # "42"
number "3.14"                   # 3.14  (nothing if it can't be parsed)
```

## Numbers

```
abs -5      floor 3.7     ceiling 3.2    round 3.5
sqrt 16     sin 0         cos 0          tan 0        atan 1
power 2, 10                           min 3, 9     max 3, 9
random 1, 6                        # dice roll (whole numbers stay whole)
random 0, 1                         # coin flip
clock                               # seconds since the program started
```

## Functions

```
function greet with name and greeting
  return greeting + ", " + name + "!"
end

greet "Ada", "Hello"               # call it as a command
print greet("Ada", "Hello")        # or where a value is needed
```

* Call it as a **command** when you don't need the result: `greet "Ada"`
* Call it **for its value** with parentheses: `set m to greet("Ada", "Hi")`
* A bare call swallows the commas that follow it on the same line. When a
  call is inside a `print` list or another call's parentheses, wrap it:
  `print find(items, 3), "done"` — use `( )` for multi-value calls anywhere
  they could be ambiguous.
* Functions can be recursive. Parameters and returns are type-inferred, so
  `fibonacci` compiles to plain C doubles and runs at full C speed.

## Files

```
save "note.txt", "buy milk"        # write a file
set contents to load "note.txt"    # read a file (nothing if missing)
if exists "note.txt"               # check
```

## Truth, equality, identity

* `is` compares numbers, text, yes/no and nothing **by value**.
* Lists and maps compare **by identity** (the same object, not the same contents).
* `0` is false. `""` is false. `no` and `nothing` are false. Everything else is true.

## Errors

DeadEnd tries to fail in English:

```
DeadEnd error (line 12): greet takes 2 values (name, greeting) but got 1
DeadEnd error (line 8): 'score' has no value (set it first, or check the spelling)
DeadEnd error (line 3): division by zero
```

## Reserved words

```
set to print if then else end repeat times forever with from by
while function return break continue for each in and or not is
more than greater less fewer bigger smaller of at least most has
yes no nothing true false use game app kit make window when starts
every frame run change exit button clicked add remove item
```

(You *can* still name a function `add` or `print` — define it with
`function add ...` and call it with parentheses.)

## How it works

`dec` parses your program, infers types (numbers stay numbers, everything
dynamic becomes a tagged value), and writes one C file. GCC compiles that
file with `-O2`. The generated C is readable — see for yourself with
`dec run file.dep --show-c`.

Memory management is reference counting with immutable text. Values you
store in lists and maps are managed for you. Reference cycles are not
collected (they're rare; the OS reclaims everything at exit).

## Animation

The motion kit animates any number in plain English -- `move`, `spring`,
timelines, particles and screen effects -- inside games and apps alike:

```
move dot.x toward 300 lasting 1.5 seconds feeling bouncy
```

It is word-matched (no new reserved words) and shares everything above.
The full reference is [`animation-kit.md`](animation-kit.md).
