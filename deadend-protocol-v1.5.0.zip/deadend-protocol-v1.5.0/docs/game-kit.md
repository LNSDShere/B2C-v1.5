# The 2D Game Kit

`use game kit` at the top of your program turns on game powers: a window,
a 60-frames-per-second loop, keyboard and mouse input, drawing, collisions,
sound and music. It is built on raylib 5.5, so it is fast and it works on
Windows, macOS and Linux.

## A complete game

```
use game kit

make game "Dot Chase" with width 400 and height 300

set dot to {x: 200, y: 150, w: 16, h: 16}
set treat to {x: 40, y: 40, w: 12, h: 12}
set score to 0

every frame
  if holding "left" then change dot.x by -4
  if holding "right" then change dot.x by 4
  if holding "up" then change dot.y by -4
  if holding "down" then change dot.y by 4

  if dot hits treat
    change score by 1
    set treat.x to random 0, 380
    set treat.y to random 0, 280
    sound "examples/assets/beep.wav"
  end

  clear "night blue"
  circle dot.x, dot.y, 8, "gold"
  box treat.x, treat.y, treat.w, treat.h, "red"
  write "Score: " + score, 10, 10, 20, "white"
end

run game
```

## The shape of a game

```
use game kit
make game "Title" with width 800 and height 600 and fps 60 and fullscreen no
set ...                        # your game state (globals -- everyone sees them)
when game starts ... end       # runs once, after the window opens
every frame ... end            # runs 60 times a second: input, logic, drawing
run game                       # opens the window and plays until it is closed
```

`make game` options (all optional): `with width 800 and height 600 and fps 60
and fullscreen yes`.

Drawing words only work inside `every frame`.

## Input

```
if holding "left"          # key held down right now
if pressed "space"         # key went down this frame
```

Key names: `"a"` to `"z"`, `"0"` to `"9"`, `"up" "down" "left" "right"`,
`"space"`, `"enter"`, `"escape"` (or `"esc"`), `"backspace"`, `"tab"`,
`"shift"`, `"ctrl"`, `"alt"`, `"delete"`, `"home"`, `"end"`, `"page up"`,
`"page down"`, `"f1"` to `"f12"`.

The mouse is a map, refreshed every frame:

```
if mouse.left                     # left button held
if mouse.right                    # right button held
if mouse.click                    # left button pressed this frame
if mouse.rclick                   # right button pressed this frame
circle mouse.x, mouse.y, 4, "white"
```

## Drawing

All positions are in pixels; (0, 0) is the top-left corner.

```
clear "night blue"                              # wipe the screen
pixel x, y, "white"                             # one dot
line x1, y1, x2, y2, "gray"                     # straight line
box x, y, width, height, "red"                  # filled rectangle
circle x, y, radius, "gold"                     # filled circle
ring x, y, radius, "white"                      # circle outline
write "Score: 10", x, y, size, "white"          # text (numbers are fine too)
image "hero.png", x, y                          # draw a picture
image "hero.png", x, y, w, h                    # stretched to a size
```

### Sprite sheets and flips

`image` can draw one frame of a sprite sheet, one piece of a picture,
or a picture upside down / left-right:

```
image "bird.png", x, y, 34, 26, frame 2 of 2       # frame 2 of a 2-frame sheet
image "bird.png", x, y, 34, 26, frame pose of 2    # the frame number can be a name
image "pipe.png", x, y, 62, 100, part 4, 18, 62, 100   # one piece, in pixels
image "pipe.png", x, y, 62, 100, part 4, 18, 62, 100, flipped  # upside down
image "bird.png", x, y, 34, 26, frame 1 of 2, mirrored  # left-right flip
```

* `frame N of M` cuts the picture into M equal frames side by side and
  draws frame N (counted from 1). Perfect for walk cycles and wing beats.
* `part x, y, w, h` draws just that rectangle of the picture. Pixel
  positions start at 0, like in image editors.
* `flipped` turns the picture upside down; `mirrored` swaps left and
  right. Both can be used together.
* The options go at the end of an `image` command, after a comma.
  With only `x, y` given (no size), a frame draws at its natural size.

A full working example of all of this:
[`examples/flappy-art.dep`](../examples/flappy-art.dep).

Colors are names (44 of them) or hex: `"red"`, `"night blue"`, `"#FF8800"`,
`"#FF8800CC"` (last two digits = transparency). The palette: black, white,
gray/grey, light gray, dark gray, red, dark red, light red, orange, gold,
yellow, green, dark green, light green, lime, mint, teal, cyan, blue,
dark blue, night blue, light blue, sky blue, navy, purple, violet, pink,
magenta, brown, tan, cream, beige, peach, coral, salmon, indigo, maroon,
olive, slate, silver.

Pictures and sounds load from the folder you run the program from.
Textures and sounds are cached automatically — calling `image` every frame
does not reload the file.

## Collisions

Give things `x`, `y`, `w` and `h` fields, then:

```
if hero hits coin              # rectangles overlap?
print distance hero.x, hero.y, coin.x, coin.y     # for circle checks
```

## Sound

```
sound "examples/assets/beep.wav"     # play a short effect
music "examples/song.ogg"            # loop background music
music ""                             # stop the music
silence                              # stop everything
```

WAV, OGG and MP3 files work. On Linux without ALSA dev headers, sound is
silently disabled and games still run.

## Timing

```
set t to time            # seconds since the game started
set d to delta           # seconds the last frame took (for smooth movement)
change hero.x by 300 * delta     # 300 pixels per second, any framerate
```

## Window

```
title "New Title"               # change the window title while running
```

## Tips

* Keep game state in globals at the top level so `every frame` and functions
  can all see it.
* `exit` (anywhere) closes the whole program. Closing the window ends
  `run game` and the program continues after it.
* Set `DEP_FRAMES=60` in the environment to auto-close the game after 60
  frames — handy for testing.

## Motion

Anything with a number animates: `move dot.x toward 300 lasting 1.5 seconds
feeling bouncy`, `spring ball.y toward 80 with wobble 6`, plus timelines,
particles (`burst 30 sparks at x, y with color "gold"`), and screen effects
(`shake screen`, `flash white`, `fade to black`, `zoom screen to 1.15`).
Full reference: [`animation-kit.md`](animation-kit.md).
