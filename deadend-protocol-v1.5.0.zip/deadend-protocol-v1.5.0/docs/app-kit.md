# The App Kit

`use app kit` gives you desktop apps: a window with real buttons, text
fields, checkboxes, sliders, labels, images and panels. No XML, no layout
language — you place widgets with `at x, y` and wire buttons to blocks.

## A complete app

```
use app kit

make window "Greeter" with width 340 and height 220

add title "Say hello" at 16, 14
add field "who" at 16, 60 with width 200
add button "Greet" at 16, 96
add label "out" at 16, 150

when button "Greet" is clicked
  set label "out" to "Hello, " + field "who" + "!"
end

run app
```

## The shape of an app

```
use app kit
make window "Title" with width 480 and height 320
add <widget> "name" at x, y [with width w and height h]
when button "name" is clicked ... end
run app
```

Top-level code runs in order, top to bottom, before the window opens — that
is where you load files and set up state. `run app` opens the window and
keeps it alive until the user closes it.

## Widgets

| Widget    | What it does                                              |
|-----------|-----------------------------------------------------------|
| `title`   | Big heading text                                           |
| `label`   | A line of text (its name is its starting text)             |
| `button`  | Clickable button — fires its `when button` block           |
| `field`   | One-line text input — click it, then type                  |
| `checkbox`| Tick box — reads as yes/no                                 |
| `slider`  | Draggable slider — reads as a number from 0 to 100         |
| `image`   | A picture loaded from the file you name                    |
| `panel`   | A background rectangle for grouping                        |

Every widget has a **name** (the text in quotes). Names must be unique —
that is how you read and change them later. Optional sizes:
`with width 200 and height 30` (either or both).

Widgets can also be added while the app runs (from a button handler, say) —
that is how `examples/todo.dep` grows its list.

## Reading and changing widgets

```
set label "out" to "anything"          # change a label's text
set field "who" to "prefilled"         # change a field's contents
set checkbox "agree" to yes            # tick / untick
set slider "size" to 40                # move the slider

print field "who"                      # what was typed (text)
print checkbox "agree"                 # yes / no
print slider "size"                    # 0 to 100
print label "out"                      # the label's current text
```

## Button events

```
when button "Greet" is clicked
  set label "out" to "Hello, " + field "who"
end
```

The block runs every time the button is clicked. You can have one block per
button.

## Fields

Click a field to give it the keyboard. Type; backspace works. Fields don't
need an "enter" event — read `field "name"` whenever you want the current
text (buttons are the natural moment).

## Files

Apps that remember things are just `save` and `load`:

```
when button "Add" is clicked
  add field "newitem" to items
  save "todo.txt", join(items, "|")
end
```

See `examples/todo.dep` for the full pattern.

## Window

```
title "New Title"               # change the window title while running
```

## Tips

* `y` grows downward; (0, 0) is the top-left of the window.
* Default sizes are chosen from the widget's text, so most widgets only need
  `at x, y`.
* Sliders read 0–100. To use them as a fraction: `slider "size" / 100`.
* Set `DEP_FRAMES=60` in the environment to auto-close the app after 60
  frames — handy for testing.

## Motion

Widgets animate: `pop in button "Go" lasting 0.4 seconds feeling bouncy`,
`slide out panel "menu" to "left"`, `glide label "coin" to 300, 200`,
`bump button "Go"`, `shake field "name" with strength 6`, `fade in panel
"card"`. A popped-out or slid-out widget stops receiving clicks until
something pops it back in. Full reference: [`animation-kit.md`](animation-kit.md).
