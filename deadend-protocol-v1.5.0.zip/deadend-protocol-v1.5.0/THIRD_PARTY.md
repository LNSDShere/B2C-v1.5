# Third-party software inside DeadEnd

## raylib 5.5 -- vendor/raylib/
A simple and easy-to-use library to enjoy videogames programming.
Copyright (c) 2013-2024 Ramon Santamaria (@raysan5).
Licensed under the zlib License. See vendor/raylib/LICENSE.txt.

raylib itself bundles: GLFW (zlib), glad (MIT), miniaudio (MIT-0/public domain),
stb libraries (public domain / MIT), dr_flac/dr_mp3/dr_wav (MIT-0),
jar_mod/jar_xm (public domain), qoi/qoaplay (MIT), and others -- all permissively
licensed. See the files under vendor/raylib/external/ for their notices.

DeadEnd only uses raylib for the 2D Game Kit and the App Kit. Programs that
use neither kit do not link raylib at all.

**DeadEnd patch:** `vendor/raylib/rcore.c` makes `InitWindow` stop when the
platform backend reports failure (upstream ignores it), so a failed graphics
init is detectable instead of crashing or exiting silently. The prebuilt
`tools/raylib/libraylib.a` is built from the patched source.

## Bundled with the Windows installer (tools/)

The one-click Windows installer ships extra components so that everything
works with zero setup. They live in `tools/` inside the install folder:

- **CPython 3.12.10** (python.org embeddable distribution, PSF license) --
  runs the `dec` compiler and DeadEnd Studio.
- **GCC 15.2.0 / MinGW-w64** (niXman mingw-builds; GCC is GPL v3 with the
  runtime library exception, MinGW-w64 headers are Zope/public domain) --
  the C compiler that turns your programs into `.exe` files. Only the
  C-language parts are included. Full notices: `tools/mingw64/licenses/`.
- **libraylib.a for Windows** -- the same raylib 5.5 as above, prebuilt for
  64-bit Windows so your first game compiles instantly.

The installer itself is built with NSIS (zlib license) and the payload is
compressed with LZMA (public domain).
