#!/usr/bin/env python3
"""dec -- the DeadEnd compiler CLI.

  dec run file.dep      compile and run a DeadEnd program
  dec build file.dep    compile into a standalone executable
  dec studio            open DeadEnd Studio (the button IDE)
  dec test              run the built-in test suite
  dec tour              start the interactive language tour
  dec doctor            check that your toolchain is ready
  dec clean             remove cached builds
  dec version | help
"""
import os
import sys
import hashlib
import subprocess
import shutil
import platform
import time

VERSION = "1.5.0"
# bump this whenever the shipped sources change, so a stale `dec` found on
# PATH (an old copy in another folder) can never be mistaken for this one:
# `dec version` prints the build tag of the code that is actually running.
DEC_BUILD = "2026-10-31a"

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(ROOT, "src")
LIB = os.path.join(ROOT, "lib")
VENDOR_RAYLIB = os.path.join(ROOT, "vendor", "raylib")
sys.path.insert(0, SRC)


def cache_dir():
    if os.environ.get("DEP_CACHE"):
        base = os.environ["DEP_CACHE"]
    elif platform.system() == "Windows":
        base = os.path.join(os.environ.get("LOCALAPPDATA",
                           os.path.expanduser("~")), "dec-cache")
    else:
        base = os.path.expanduser("~/.cache/dec")
    d = os.path.join(base, "v" + VERSION)
    os.makedirs(d, exist_ok=True)
    return d


def find_compiler():
    cands = []
    if os.environ.get("CC"):
        cands.append(os.environ["CC"])
    if platform.system() == "Windows":
        # the compiler that ships in the DeadEnd installer
        bundled = os.path.join(ROOT, "tools", "mingw64", "bin", "gcc.exe")
        if os.path.isfile(bundled):
            cands.append(bundled)
    cands += ["gcc", "clang", "cc"]
    for cc in cands:
        if not cc:
            continue
        if os.path.isabs(cc) or ("\\" in cc) or ("/" in cc):
            if os.path.isfile(cc):
                return cc
        elif shutil.which(cc):
            return cc
    return None


def sysroot_args():
    """Sandbox/testing support: DEP_SYSROOT points at extra headers+libs."""
    sr = os.environ.get("DEP_SYSROOT")
    if not sr:
        return [], []
    inc = ["-I", os.path.join(sr, "usr", "include")]
    libdirs = [os.path.join(sr, "usr", "lib", "x86_64-linux-gnu"),
               os.path.join(sr, "usr", "lib64"), os.path.join(sr, "usr", "lib")]
    lib = []
    for d in libdirs:
        if os.path.isdir(d):
            lib += ["-L", d]
    return inc, lib


def raylib_dir():
    """Where a built libraylib.a lives (or will be built)."""
    env = os.environ.get("DEP_RAYLIB_BUILD")
    if env and os.path.isfile(os.path.join(env, "libraylib.a")):
        return env
    if platform.system() == "Windows":
        # prebuilt win64 raylib shipped by the DeadEnd installer
        bundled = os.path.join(ROOT, "tools", "raylib")
        if os.path.isfile(os.path.join(bundled, "libraylib.a")):
            return bundled
    # bug fix (43): the build dir is version-specific, so updating dec
    # always rebuilds raylib from the (possibly patched) vendored sources
    # instead of silently reusing a library built by an older version
    return os.path.join(cache_dir(), "raylib-" + VERSION)


def platform_link_libs(rl_dir):
    sysname = platform.system()
    if sysname == "Windows":
        return ["-lopengl32", "-lgdi32", "-lwinmm"]
    if sysname == "Darwin":
        return ["-framework", "OpenGL", "-framework", "Cocoa",
                "-framework", "IOKit", "-framework", "CoreAudio",
                "-framework", "CoreVideo"]
    libs = ["-lGL", "-lX11", "-lXrandr", "-lXi", "-lXcursor",
            "-lXinerama", "-lm", "-lpthread", "-ldl", "-lrt"]
    audio_file = os.path.join(rl_dir, "audio.txt")
    if os.path.isfile(audio_file):
        try:
            with open(audio_file) as f:
                if "DEP_AUDIO=1" in f.read():
                    libs.append("-lasound")
        except OSError:
            pass
    return libs


def build_raylib(quiet=False):
    rl_dir = raylib_dir()
    if os.path.isfile(os.path.join(rl_dir, "libraylib.a")):
        return rl_dir
    if not quiet:
        sys.stderr.write("First time using a kit: building raylib (about a "
                         "minute, only once)...\n")
    os.makedirs(rl_dir, exist_ok=True)
    inc, _ = sysroot_args()
    cc = find_compiler()
    if not cc:
        die("building raylib needs a C compiler, and none was found.\n"
            "  Windows: install MinGW-w64 (see README.md):\n"
            "    1. go to   https://winlibs.com/\n"
            "    2. download the latest \"Win64\" release (UCRT is fine)\n"
            "    3. unzip it anywhere, for example  C:\\mingw64\n"
            "    4. add  C:\\mingw64\\bin  to your PATH (open a NEW terminal)\n"
            "  Linux:  sudo apt install build-essential\n"
            "  macOS:  xcode-select --install")
    _build_raylib_direct(cc, rl_dir, inc, quiet=quiet)
    if not os.path.isfile(os.path.join(rl_dir, "libraylib.a")):
        die("could not build raylib -- see the messages above. "
            "On Linux install: sudo apt install libgl1-mesa-dev libasound2-dev "
            "libxrandr-dev libxi-dev libxcursor-dev libxinerama-dev")
    if not quiet:
        sys.stderr.write("raylib ready.\n")
    return rl_dir


def _build_raylib_direct(cc, rl_dir, inc, quiet=False):
    """Build the vendored raylib 5.5 with the plain C compiler + ar.

    Bug fix (24): this used to run `sh vendor/raylib/build_raylib.sh`, which
    cannot work on Windows (no POSIX shell there -- it crashed with a raw
    `FileNotFoundError: [WinError 2]` traceback) and would also fail under
    Git-Bash (the script cannot select the Win32 GLFW backend). Compiling
    the sources directly needs nothing but the C compiler and `ar` -- both
    ship with MinGW-w64. The flags mirror build_raylib.sh exactly.
    """
    rd = VENDOR_RAYLIB
    base = ["-O2", "-DPLATFORM_DESKTOP", "-DGRAPHICS_API_OPENGL_33"]
    if platform.system() == "Windows":
        base.append("-D_GLFW_WIN32")
    else:
        base += ["-D_GLFW_X11", "-fPIC"]
    base += ["-I", rd, "-I", os.path.join(rd, "external", "glfw", "include"),
             *inc, "-w"]
    objs = []
    audio_ok = True
    for name in ("rcore", "rglfw", "rshapes", "rtextures",
                 "rtext", "rmodels", "raudio", "utils"):
        obj = os.path.join(rl_dir, name + ".o")
        objs.append(obj)
        cmd = [cc, *base, "-c", os.path.join(rd, name + ".c"), "-o", obj]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0 and name == "raudio":
            # Linux without ALSA headers: rebuild without sound support
            audio_ok = False
            if not quiet:
                sys.stderr.write("note: ALSA headers not found -- building "
                                 "without sound support\n")
            cmd = [cc, *base, "-DMA_NO_ALSA",
                   "-c", os.path.join(rd, "raudio.c"), "-o", obj]
            r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            if quiet:
                sys.stderr.write(r.stderr)
            die(f"could not compile raylib ({name}.c) with '{cc}' -- "
                "see the messages above")
    # find `ar`: on Windows it lives next to gcc.exe in the MinGW bin dir
    ar = shutil.which("ar")
    if (platform.system() == "Windows") or ("\\" in cc) or ("/" in cc):
        cand = os.path.join(os.path.dirname(cc),
                            "ar.exe" if platform.system() == "Windows" else "ar")
        if os.path.isfile(cand):
            ar = cand
    lib = os.path.join(rl_dir, "libraylib.a")
    if os.path.exists(lib):
        os.remove(lib)
    r = subprocess.run([ar, "rcs", lib, *objs], capture_output=True, text=True)
    if r.returncode != 0:
        if quiet:
            sys.stderr.write(r.stderr)
        die("could not archive libraylib.a ('ar' not found?) -- "
            "see the messages above")
    with open(os.path.join(rl_dir, "audio.txt"), "w") as f:
        f.write(f"DEP_AUDIO={1 if audio_ok else 0}\n")


def die(msg, code=1):
    sys.stderr.write(f"dec: {msg}\n")
    sys.exit(code)


def compile_program(path, want_kits, debug=False, show_c=False):
    """Parse+transpile+compile. Returns path to executable."""
    from dep_parse import DepError, parse
    from dep_emit import Compiler

    try:
        with open(path, "r", encoding="utf-8") as f:
            src = f.read()
    except OSError as e:
        die(f"cannot read {path}: {e}")

    try:
        ast = parse(src)
        comp = Compiler(ast)
        c_code = comp.compile()
    except DepError as e:
        die(f"{os.path.basename(path)}: error: {e}")

    kits = bool(comp.kit)

    if show_c:
        print(c_code)

    cc = find_compiler()
    if not cc:
        die("DeadEnd compiles programs to native code, so it needs a C "
            "compiler.\n"
            "  Linux:  sudo apt install build-essential\n"
            "  macOS:  xcode-select --install\n"
            "  Windows: install MinGW-w64 (see README.md)")

    # the cache key must include the runtime libs, not just the generated
    # C -- otherwise a fixed lib/*.c keeps serving stale binaries.
    fp = hashlib.sha1()
    for lib_src in ("dep_runtime.c", "motionkit.c", "gamekit.c", "appkit.c"):
        p = os.path.join(LIB, lib_src)
        if os.path.isfile(p):
            with open(p, "rb") as f:
                fp.update(hashlib.sha1(f.read()).digest())
    key = hashlib.sha1(
        (VERSION + c_code + fp.hexdigest() +
         ("debug" if debug else "")).encode()
    ).hexdigest()[:16]
    out_dir = os.path.join(cache_dir(), key)
    os.makedirs(out_dir, exist_ok=True)
    exe = os.path.join(out_dir, "program")
    if platform.system() == "Windows":
        exe += ".exe"
    c_path = os.path.join(out_dir, "program.c")

    force = os.environ.get("DEP_FORCE")
    if os.path.isfile(exe) and not force:
        return exe

    with open(c_path, "w", encoding="utf-8") as f:
        f.write(c_code)

    inc, lib = sysroot_args()
    cmd = [cc, "-O2" if not debug else "-O0", "-w",
           "-I", LIB, "-I", VENDOR_RAYLIB,
           *inc, *lib,
           "-o", exe, c_path,
           os.path.join(LIB, "dep_runtime.c"),
           os.path.join(LIB, "motionkit.c")]
    rl_dir = None
    if kits:
        rl_dir = build_raylib()
        cmd += [os.path.join(LIB, "gamekit.c"),
                os.path.join(LIB, "appkit.c"),
                "-I", VENDOR_RAYLIB,
                os.path.join(rl_dir, "libraylib.a")]
        cmd += platform_link_libs(rl_dir)
        if platform.system() == "Windows":
            cmd += ["-mwindows"]   # games open a window, not a console
    if platform.system() == "Windows":
        # static libgcc/libwinpthread: the exe must not depend on MinGW
        # runtime DLLs that a plain Windows box does not have
        cmd += ["-static"]
    if platform.system() != "Windows":
        cmd += ["-lm"]

    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        sys.stderr.write(r.stderr)
        die("compilation failed -- this is a bug in dec, please report it "
            "with the code above")
    return exe


def cmd_run(args):
    paths = [a for a in args if not a.startswith("-")]
    if not paths:
        die("usage: dec run file.dep [--debug] [--show-c]")
    path = paths[0]
    if len(paths) > 1:
        die("dec run takes one program file")
    debug = "--debug" in args
    show_c = "--show-c" in args
    exe = compile_program(path, None, debug=debug, show_c=show_c)
    if platform.system() != "Windows":
        os.execv(exe, [exe])
    # Bug fix (26): Windows GUI-subsystem programs die silently -- a failed
    # window init or a missing DLL leaves zero output and cmd just returns.
    # Run it as a child, keep the console attached, and decode the exit code.
    rc = subprocess.call([exe])
    if rc == 0:
        return
    note = {
        3221225781: "a DLL the program needs was not found (Windows error "
                    "0xC0000135). Run 'dec doctor' -- its kit link test will "
                    "pin down which library is the problem.",
        3221225477: "the program crashed inside Windows (access violation, "
                    "0xC0000005) -- this is a bug in the generated program or "
                    "the runtime, please report it.",
        3221226505: "the program crashed at startup (0xC0000409 / stack "
                    "check failure), please report it.",
        1: "the program exited with an error -- most likely the window or "
           "the graphics device failed to initialize. Re-run with raylib's "
           "own messages visible:   set DEP_TRACE=1\n"
           "then run the same command again and read the lines it prints.",
    }.get(rc, "")
    sys.stderr.write(f"\n[DeadEnd] the program closed with exit code {rc} "
                     f"(0x{rc & 0xffffffff:08x}).\n")
    if note:
        sys.stderr.write(f"[DeadEnd] {note}\n")
    sys.stderr.write(f"[DeadEnd] the built program is at: {exe}\n"
                     "[DeadEnd] running that file directly shows any error "
                     "text a windowed program otherwise hides.\n")
    sys.exit(1)


def cmd_build(args):
    if not args:
        die("usage: dec build file.dep [-o name]")
    rest = list(args)
    out = None
    while "-o" in rest:
        j = rest.index("-o")
        if j + 1 >= len(rest):
            die("-o needs a name after it: dec build file.dep -o mygame")
        out = rest[j + 1]
        del rest[j:j + 2]
    paths = [a for a in rest if not a.startswith("-")]
    if not paths:
        die("usage: dec build file.dep [-o name]")
    if len(paths) > 1:
        die("dec build takes one program file")
    path = paths[0]
    debug = "--debug" in rest
    if out is None:
        out = os.path.splitext(os.path.basename(path))[0]
        if platform.system() == "Windows":
            out += ".exe"
    exe = compile_program(path, None, debug=debug)
    out_dir = os.path.dirname(os.path.abspath(out))
    if out_dir and not os.path.isdir(out_dir):
        try:
            os.makedirs(out_dir, exist_ok=True)
        except OSError:
            die(f"cannot write {out}: no directory {out_dir}")
    shutil.copy2(exe, out)
    print(f"built {out}")


def cmd_test(args):
    tests_dir = os.path.join(ROOT, "tests")
    if not os.path.isdir(tests_dir):
        die("no tests directory found")
    files = sorted(f for f in os.listdir(tests_dir) if f.endswith(".dep"))
    passed = failed = skipped = 0
    for f in files:
        path = os.path.join(tests_dir, f)
        expected_path = path[:-4] + ".expected"
        # kit tests need a display; skip gracefully when headless
        try:
            with open(path, encoding="utf-8") as sf:
                src = sf.read()
        except OSError:
            continue
        if ("use game kit" in src or "use app kit" in src) and \
                not os.environ.get("DISPLAY"):
            skipped += 1
            print(f"  skip  {f} (needs a display)")
            continue
        try:
            with open(expected_path, encoding="utf-8") as ef:
                expected = ef.read()
        except OSError:
            expected = None
        try:
            exe = compile_program(path, None)
            r = subprocess.run([exe], capture_output=True, text=True,
                               timeout=60,
                               env={**os.environ, "DEP_FRAMES": "3"})
            actual = r.stdout
            if expected is not None:
                if actual == expected and r.returncode == 0:
                    passed += 1
                    print(f"  ok    {f}")
                else:
                    failed += 1
                    print(f"  FAIL  {f}")
                    if actual != expected:
                        import difflib
                        for line in difflib.unified_diff(
                                expected.splitlines(), actual.splitlines(),
                                "expected", "actual", lineterm=""):
                            print("        " + line)
            else:
                if r.returncode == 0:
                    passed += 1
                    print(f"  ok    {f}")
                else:
                    failed += 1
                    print(f"  FAIL  {f} (exit {r.returncode})")
                    sys.stderr.write(r.stderr)
        except Exception as e:
            failed += 1
            print(f"  FAIL  {f} ({e})")
    print(f"\n{passed} passed, {failed} failed, {skipped} skipped, {len(files)} total")
    sys.exit(1 if failed else 0)


def cmd_doctor(args):
    print(f"dec {VERSION} -- doctor (build {DEC_BUILD})")
    print(f"  python      : {platform.python_version()}  [{sys.executable}]")
    cc = find_compiler()
    print(f"  C compiler  : {cc or 'NOT FOUND'}")
    if cc:
        r = subprocess.run([cc, "--version"], capture_output=True, text=True)
        print("               " + (r.stdout.splitlines() or [""])[0])
    print(f"  package     : {ROOT}")
    print(f"  cache       : {cache_dir()}")
    rl = os.path.join(raylib_dir(), "libraylib.a")
    print(f"  raylib      : {'built' if os.path.isfile(rl) else 'not built yet (builds on first game/app)'}")
    # try compiling the hello world
    hello = os.path.join(cache_dir(), "doctor.dep")
    with open(hello, "w") as f:
        f.write('print "doctor: ' + VERSION + ' ok"\n')
    try:
        exe = compile_program(hello, None)
        r = subprocess.run([exe], capture_output=True, text=True, timeout=60)
        print(f"  smoke test  : {'PASS' if r.returncode == 0 else 'FAIL'}")
        if r.returncode != 0:
            sys.stderr.write(r.stderr)
    except SystemExit:
        print("  smoke test  : FAIL")
    # Bug fix (26): also link a kit program WITHOUT running it -- this is the
    # test that catches "your gcc and the shipped/prebuilt raylib disagree"
    # before the user ever loses an evening to a silently closing window.
    if cc:
        try:
            kit = os.path.join(cache_dir(), "doctor-kit.dep")
            with open(kit, "w") as f:
                f.write('use game kit\n'
                        'make game "Doctor" with width 320 and height 240\n'
                        'every frame\n'
                        '  clear "black"\n'
                        '  write "doctor", 10, 10, 20, "white"\n'
                        'end\n'
                        'run game\n')
            kexe = compile_program(kit, None)
            print(f"  kit link    : PASS (built {os.path.basename(os.path.dirname(kexe))})")
        except SystemExit:
            print("  kit link    : FAIL")
        except Exception as e:
            print(f"  kit link    : FAIL ({e})")
    print("\nAll good -- go make something.")


def cmd_clean(args):
    import glob
    d = cache_dir()
    for entry in glob.glob(os.path.join(d, "*")):
        shutil.rmtree(entry, ignore_errors=True)
    print(f"cleared {d}")


def cmd_tour(args):
    from dep_tour import run_tour
    run_tour(ROOT, lambda path: compile_program(path, None))


def cmd_studio(args):
    from studio import main as studio_main
    sys.exit(studio_main(args))


HELP = """dec -- the DeadEnd compiler, version {v}

usage:
  dec run file.dep            compile and run a program
  dec run file.dep --show-c   also print the generated C code
  dec build file.dep [-o n]   compile into a standalone executable
  dec studio                  open DeadEnd Studio (buttons, no terminal)
  dec test                    run the test suite that ships with DeadEnd
  dec tour                    an interactive tour of the whole language
  dec doctor                  check your toolchain
  dec clean                   clear cached builds
  dec version                 print the version

quick start:
  dec studio
""".format(v=VERSION)


def main():
    argv = sys.argv[1:]
    if not argv or argv[0] in ("help", "--help", "-h"):
        print(HELP)
        return
    if argv[0] in ("version", "--version", "-v"):
        print(f"dec {VERSION} -- DeadEnd compiler (build {DEC_BUILD})")
        return
    cmd = argv[0]
    rest = argv[1:]
    if cmd == "run":
        cmd_run(rest)
    elif cmd == "build":
        cmd_build(rest)
    elif cmd == "test":
        cmd_test(rest)
    elif cmd == "doctor":
        cmd_doctor(rest)
    elif cmd == "clean":
        cmd_clean(rest)
    elif cmd == "tour":
        cmd_tour(rest)
    elif cmd == "studio":
        cmd_studio(rest)
    else:
        # convenience: dec hello.dep == dec run hello.dep
        if cmd.endswith(".dep"):
            cmd_run(argv)
        else:
            die(f"unknown command '{cmd}'. try: dec help")


if __name__ == "__main__":
    main()
